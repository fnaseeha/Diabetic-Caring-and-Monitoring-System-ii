<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "medical";
//$servername = "localhost";
//$username = "root";
//$password = "";
//$database = "appareltech";
// Create connection
$conn = new mysqli($servername, $username, $password, $database) or die ("ERROR: Database");
/**
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
 **/
?>
